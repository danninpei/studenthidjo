// JS Hover Navbar, tanda ada di halaman berapa di navigasi bar
document.addEventListener("DOMContentLoaded", function () {
  const navbarItems = document.querySelectorAll(".li-navbar a");

  // Ambil path halaman yang sedang dibuka
  const currentPath = window.location.pathname.split("/").pop();

  // Cek apakah ada item aktif yang tersimpan di localStorage
  const activeNav = localStorage.getItem("activeNav");

  navbarItems.forEach((item) => {
    const itemPath = item.getAttribute("href");

    // Jika path halaman cocok dengan href menu, tandai sebagai aktif
    if (itemPath === currentPath || itemPath === activeNav) {
      item.parentElement.classList.add("active");
    }

    item.addEventListener("click", function () {
      // Hapus kelas aktif dari semua item
      navbarItems.forEach(nav => nav.parentElement.classList.remove("active"));

      // Tambahkan kelas aktif ke elemen yang diklik
      this.parentElement.classList.add("active");

      // Simpan di localStorage agar tetap aktif setelah reload
      localStorage.setItem("activeNav", this.getAttribute("href"));
    });
  });
});

// JS Hover Navbar End
// JS Search Machine blm bisa
document.addEventListener("DOMContentLoaded", function () {
  console.log("JS Loaded & DOM Ready");

  const searchForm = document.querySelector(".search-form");
  const searchInput = document.querySelector(".search-input");

  if (!searchForm || !searchInput) {
      console.error("Error: Search form atau input tidak ditemukan!");
      return;
  }

  searchForm.addEventListener("submit", function (event) {
      event.preventDefault(); // Mencegah reload halaman

      const query = searchInput.value.trim(); // Ambil teks input

      if (query !== "") {
          console.log("Pencarian:", query);
          
          // Redirect ke search.html dengan parameter pencarian
          window.location.href = `search.html?q=${encodeURIComponent(query)}`;
      } else {
          alert("Masukkan kata kunci untuk mencari!");
      }
  });
});
// JS Search Machine End

// JS QnA 
document.addEventListener("DOMContentLoaded", function () {
    // Toggle kategori FAQ
    const faqCategories = document.querySelectorAll(".QnA-category-title");

    faqCategories.forEach((category) => {
        category.addEventListener("click", () => {
            const content = category.nextElementSibling;

            // Tutup semua kategori lain sebelum membuka yang baru
            document.querySelectorAll(".QnA-content").forEach((faq) => {
                if (faq !== content) {
                    faq.style.display = "none";
                    faq.previousElementSibling.classList.remove("active");
                }
            });
            
            // Toggle tampilan kategori
            category.classList.toggle("active");
            content.style.display = content.style.display === "block" ? "none" : "block";
        });
    });
    // Toggle untuk pertanyaan dalam kategori
    const faqItems = document.querySelectorAll(".QnA-item");

    faqItems.forEach((item) => {
        const question = item.querySelector(".QnA-question");

        question.addEventListener("click", () => {
            // Tutup semua jawaban lain dalam kategori yang sama
            item.parentElement.querySelectorAll(".QnA-item").forEach((faq) => {
                if (faq !== item) {
                    faq.classList.remove("active");
                }
            });
            // Toggle tampilan jawaban
            item.classList.toggle("active");
        });
    });
});
// JS QnA End 
